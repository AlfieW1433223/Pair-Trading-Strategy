# GitHub Upload Checklist

Upload these files/folders:

```text
.gitignore
README.md
GITHUB_UPLOAD_CHECKLIST.md
RunCodes.py
run_project.py
requirements.txt
src/
tests/
outputs/pairs_trading_notes.md
outputs_real/cointegration_tests_all_pairs.csv
outputs_real/cointegrated_pairs.csv
outputs_real/performance_metrics.csv
outputs_real/in_sample_out_of_sample.csv
outputs_real/sensitivity_analysis.csv
outputs_real/portfolio_equity.csv
```

Optional real-data detail files:

```text
outputs_real/backtest_*.csv
outputs_real/trade_log_*.csv
outputs_real/input_prices_reference.csv
```

Do not upload:

```text
work/
__pycache__/
*.pyc
.DS_Store
venv/
.venv/
.env
```

After cloning, a reviewer should be able to run:

```bash
pip install -r requirements.txt
python3 RunCodes.py --help
python3 -m unittest discover tests
python3 RunCodes.py
```

To reproduce the real-data run:

```bash
python3 RunCodes.py --sp500 --max-tickers 50 --output-dir outputs_real --start 2018-01-01 --end 2026-08-31 --max-pairs 5 --cost-bps 10
```
